import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { listPublicPartners, type Partner } from '@/data/partners'

export function PartnerLogo({partner}:{partner:Partner}){
 const content=<div className="group flex h-24 items-center justify-center rounded-xl border border-[var(--color-border)] bg-white p-4 transition-shadow hover:shadow-md md:h-28" title={partner.name_ar}>
  {partner.logo_url?<img src={partner.logo_url} alt={partner.name_ar} loading="lazy" decoding="async" className="max-h-[76px] w-full max-w-[180px] object-contain grayscale transition-[filter] duration-300 group-hover:grayscale-0 group-focus-within:grayscale-0 group-active:grayscale-0"/>:<span className="text-center text-sm font-bold text-[var(--color-text)]">{partner.name_ar}</span>}
 </div>
 return partner.website_url?<a href={partner.website_url} target="_blank" rel="noopener noreferrer" aria-label={'موقع '+partner.name_ar} className="block rounded-xl focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--color-accent)]">{content}</a>:content
}
export default function AuthorizedPartnersSection(){
 const [partners,setPartners]=useState<Partner[]>([])
 useEffect(()=>{let active=true;void listPublicPartners().then(list=>{if(active)setPartners(list.filter(p=>p.show_home).slice(0,12))}).catch(()=>{});return()=>{active=false}},[])
 if(!partners.length)return null
 return <section dir="rtl" aria-labelledby="authorized-partners-title" className="border-t border-[var(--color-border)] bg-[var(--color-surface)]">
  <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-16 md:py-20">
   <div className="mb-8 text-center"><p className="text-xs font-semibold text-[var(--color-accent)]">CHEF MUJAHED PARTNERS</p><h2 id="authorized-partners-title" className="mt-2 text-2xl font-bold md:text-3xl">شركاؤنا المعتمدون</h2><p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-[var(--color-text-muted)]">تعرف على الجهات التي يؤكد الشيف مجاهد تعامله معها حاليًا.</p></div>
   <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">{partners.map(p=><PartnerLogo key={p.id} partner={p}/>)}</div>
   <div className="mt-8 text-center"><Link to="/partners" className="inline-flex min-h-11 items-center justify-center rounded-xl border border-[var(--color-border)] px-6 text-sm font-semibold hover:bg-[var(--color-bg)]">عرض دليل الشركاء والتحقق من المحلات</Link></div>
  </div>
 </section>
}
