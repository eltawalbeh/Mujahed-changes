import { useEffect,useMemo,useState } from 'react'
import { Link } from 'react-router-dom'
import { listPublicPartners,type Partner } from '@/data/partners'
import { PartnerLogo } from '@/components/public/AuthorizedPartnersSection'
import PublicHeader from '@/components/public/PublicHeader'
import PublicFooter from '@/components/public/PublicFooter'
export default function AuthorizedPartnersPage(){
 const [partners,setPartners]=useState<Partner[]>([]),[search,setSearch]=useState(''),[city,setCity]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(true)
 useEffect(()=>{let active=true;void listPublicPartners().then(data=>{if(active)setPartners(data)}).catch(()=>{if(active)setError('تعذر تحميل الدليل. حاول مجددًا لاحقًا.')}).finally(()=>{if(active)setLoading(false)});return()=>{active=false}},[])
 const cities=useMemo(()=>Array.from(new Set(partners.map(p=>p.city).filter((x):x is string=>Boolean(x)))).sort((a,b)=>a.localeCompare(b,'ar')),[partners])
 const filtered=useMemo(()=>partners.filter(p=>(!city||p.city===city)&&(!search.trim()||[p.name_ar,p.name_en,p.city].some(x=>x?.toLowerCase().includes(search.trim().toLowerCase())))),[partners,search,city])
 return <div className="min-h-screen bg-[var(--color-bg)]"><PublicHeader/><main dir="rtl" className="mx-auto max-w-[1440px] px-4 py-12 md:px-16 md:py-20">
  <Link to="/" className="text-xs underline underline-offset-4">الرئيسية</Link><h1 className="mt-5 text-3xl font-bold">دليل الشركاء المعتمدين</h1>
  <p className="mt-3 max-w-3xl text-sm leading-7 text-[var(--color-text-muted)]">هذه قائمة بالجهات التي يؤكد الشيف مجاهد تعامله معها حاليًا. يُحدّث الدليل دوريًا، وعدم ظهور جهة لا يُعدّ وحده دليلًا على أي مخالفة.</p>
  <div className="mt-8 grid gap-3 sm:grid-cols-[1fr_220px]"><input aria-label="ابحث عن محل" value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث باسم المحل" className="min-h-12 rounded-xl border border-[var(--color-border)] bg-white px-4 text-sm"/><select aria-label="المدينة" value={city} onChange={e=>setCity(e.target.value)} className="min-h-12 rounded-xl border border-[var(--color-border)] bg-white px-4 text-sm"><option value="">جميع المدن</option>{cities.map(v=><option key={v} value={v}>{v}</option>)}</select></div>
  <p aria-live="polite" className="my-5 text-xs text-[var(--color-text-muted)]">{loading?'جاري تحميل الدليل…':error||'عدد الجهات المعتمدة المطابقة: '+filtered.length}</p>
  {!loading&&!error?<div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">{filtered.map(p=><article key={p.id}><PartnerLogo partner={p}/><p className="mt-2 text-center text-sm font-semibold">{p.name_ar}</p>{p.city?<p className="text-center text-xs text-[var(--color-text-muted)]">{p.city}</p>:null}</article>)}</div>:null}
  {!loading&&!error&&!filtered.length?<p className="rounded-xl bg-white p-6 text-center text-sm">لا توجد نتائج مطابقة. جرّب اسمًا آخر.</p>:null}
 </main><PublicFooter/></div>
}
