import { useCallback,useEffect,useMemo,useState } from 'react'
import { Link } from 'react-router-dom'
import ImageUploadField from '@/components/dashboard/ImageUploadField'
import { listManagedPartners,removePartner,savePartner,type Partner,type PartnerInput,type PartnerStatus } from '@/data/partners'
import { useDashboard } from '@/state/DashboardContext'
const blank=():PartnerInput=>({id:crypto.randomUUID(),name_ar:'',name_en:null,city:null,logo_url:null,website_url:null,status:'DRAFT',show_home:false,sort_order:0})
const statuses:[PartnerStatus,string][]=[['DRAFT','مسودة'],['APPROVED','معتمد ومنشور'],['INACTIVE','غير نشط']]
export default function DashboardPartnersPage(){
 const {role}=useDashboard()
 const [items,setItems]=useState<Partner[]>([]),[draft,setDraft]=useState<PartnerInput|null>(null),[query,setQuery]=useState(''),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[message,setMessage]=useState('')
 const load=useCallback(async()=>{setLoading(true);try{setItems(await listManagedPartners());setMessage('')}catch(e){setMessage(e instanceof Error?e.message:'تعذر تحميل الشركاء')}finally{setLoading(false)}},[])
 useEffect(()=>{void load()},[load])
 const visible=useMemo(()=>items.filter(p=>[p.name_ar,p.name_en,p.city].some(v=>v?.toLowerCase().includes(query.toLowerCase()))),[items,query])
 const update=<K extends keyof PartnerInput>(k:K,v:PartnerInput[K])=>setDraft(old=>old?{...old,[k]:v}:old)
 const save=async()=>{
  if(!draft||!draft.name_ar.trim()){setMessage('اسم الشريك مطلوب.');return}
  if(draft.status==='APPROVED'&&!draft.logo_url){setMessage('ارفع شعار الشريك قبل اعتماده.');return}
  if(draft.website_url&&!/^https:\/\//i.test(draft.website_url)){setMessage('يجب أن يبدأ رابط الموقع بـ https://');return}
  setBusy(true);try{await savePartner({...draft,name_ar:draft.name_ar.trim(),name_en:draft.name_en?.trim()||null,city:draft.city?.trim()||null,website_url:draft.website_url?.trim()||null});setDraft(null);await load();setMessage('تم حفظ الشريك بنجاح.')}catch(e){setMessage(e instanceof Error?e.message:'تعذر الحفظ')}finally{setBusy(false)}
 }
 const remove=async(p:Partner)=>{if(!window.confirm('حذف '+p.name_ar+' من الدليل نهائيًا؟'))return;setBusy(true);try{await removePartner(p.id);await load();setMessage('تم الحذف.')}catch(e){setMessage(e instanceof Error?e.message:'تعذر الحذف')}finally{setBusy(false)}}
 if(role!=='SUPER_ADMIN'&&role!=='ADMIN')return <main className="p-6">هذا القسم متاح للمدير ومدير النظام فقط.</main>
 return <main dir="rtl" className="space-y-5 p-4 lg:p-8">
  <header className="flex flex-wrap items-center justify-between gap-3"><div><Link to="/dashboard/content" className="text-xs underline">العودة إلى إدارة المحتوى</Link><h1 className="mt-2 text-2xl font-bold">الشركاء المعتمدون</h1><p className="text-xs text-[var(--color-text-muted)]">الجهات المعتمدة فقط تظهر على الموقع. حالة المسودة وغير النشط لا تظهران للعامة.</p></div><button type="button" onClick={()=>{setMessage('');setDraft(blank())}} className="min-h-11 rounded-xl bg-[var(--color-text)] px-5 text-sm font-semibold text-white">إضافة شريك</button></header>
  <input aria-label="بحث عن شريك" value={query} onChange={e=>setQuery(e.target.value)} placeholder="بحث باسم الشريك أو المدينة" className="h-12 w-full rounded-xl border border-[var(--color-border)] bg-white px-4 text-sm"/>
  {message?<p role="status" className="rounded-xl border border-[var(--color-border)] bg-white p-3 text-sm">{message}</p>:null}
  {draft?<section className="space-y-4 rounded-2xl border border-[var(--color-border)] bg-white p-5"><h2 className="font-bold">{items.some(x=>x.id===draft.id)?'تعديل شريك':'شريك جديد'}</h2>
   <div className="grid gap-3 sm:grid-cols-2">
    <label className="text-sm">اسم المحل بالعربية *<input value={draft.name_ar} onChange={e=>update('name_ar',e.target.value)} className="mt-1 block h-11 w-full rounded-xl border px-3"/></label>
    <label className="text-sm">الاسم بالإنجليزية<input value={draft.name_en||''} onChange={e=>update('name_en',e.target.value)} className="mt-1 block h-11 w-full rounded-xl border px-3"/></label>
    <label className="text-sm">المدينة<input value={draft.city||''} onChange={e=>update('city',e.target.value)} className="mt-1 block h-11 w-full rounded-xl border px-3"/></label>
    <label className="text-sm">رابط الموقع (اختياري)<input dir="ltr" type="url" value={draft.website_url||''} onChange={e=>update('website_url',e.target.value)} placeholder="https://" className="mt-1 block h-11 w-full rounded-xl border px-3"/></label>
    <label className="text-sm">حالة الشريك<select value={draft.status} onChange={e=>update('status',e.target.value as PartnerStatus)} className="mt-1 block h-11 w-full rounded-xl border px-3">{statuses.map(([v,n])=><option key={v} value={v}>{n}</option>)}</select></label>
    <label className="text-sm">ترتيب الظهور<input type="number" value={draft.sort_order} onChange={e=>update('sort_order',Number(e.target.value)||0)} className="mt-1 block h-11 w-full rounded-xl border px-3"/></label>
   </div>
   <ImageUploadField label="شعار الشريك" value={draft.logo_url||''} onChange={v=>update('logo_url',v||null)} storagePath={'partners/'+draft.id+'/logo'} help="صورة الشعار الأصلية ملونة، سيظهر بلون واحد افتراضيًا وبألوانه عند Hover." recommendedSize="600 × 400 px" sharedNote=""/>
   <label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={draft.show_home} onChange={e=>update('show_home',e.target.checked)}/> إظهار الشريك ضمن الصفحة الرئيسية (حد أقصى 12)</label>
   <div className="flex gap-3"><button type="button" disabled={busy} onClick={()=>void save()} className="min-h-11 rounded-xl bg-[var(--color-text)] px-5 text-sm text-white disabled:opacity-60">حفظ</button><button type="button" onClick={()=>setDraft(null)} className="min-h-11 rounded-xl border px-5 text-sm">إلغاء</button></div>
  </section>:null}
  <section className="overflow-hidden rounded-2xl border border-[var(--color-border)] bg-white">{loading?<p className="p-5 text-sm">جاري التحميل…</p>:visible.length?visible.map(p=><article key={p.id} className="flex flex-wrap items-center justify-between gap-3 border-b p-4 last:border-0"><div className="flex items-center gap-3">{p.logo_url?<img src={p.logo_url} alt="" className="size-14 rounded-lg object-contain"/>:<div className="size-14 rounded-lg bg-[var(--color-bg)]"/>}<div><strong className="text-sm">{p.name_ar}</strong><p className="text-xs text-[var(--color-text-muted)]">{p.city||'—'} · {statuses.find(s=>s[0]===p.status)?.[1]||p.status}{p.show_home?' · الرئيسية':''}</p></div></div><div className="flex gap-2"><button type="button" disabled={busy} onClick={()=>{setMessage('');setDraft({id:p.id,name_ar:p.name_ar,name_en:p.name_en,city:p.city,logo_url:p.logo_url,website_url:p.website_url,status:p.status,show_home:p.show_home,sort_order:p.sort_order})}} className="min-h-11 rounded-lg border px-4 text-sm">تعديل</button><button type="button" disabled={busy} onClick={()=>void remove(p)} className="min-h-11 rounded-lg border border-red-200 px-4 text-sm text-red-700">حذف</button></div></article>):<p className="p-6 text-center text-sm">لا يوجد شركاء بعد.</p>}</section>
 </main>
}
