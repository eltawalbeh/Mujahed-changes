import { supabase } from '@/lib/supabase'
export type PartnerStatus='DRAFT'|'APPROVED'|'INACTIVE'
export type Partner={
 id:string;name_ar:string;name_en:string|null;city:string|null;logo_url:string|null;
 website_url:string|null;status:PartnerStatus;show_home:boolean;sort_order:number;
 verified_at:string|null;created_at:string;updated_at:string
}
export type PartnerInput=Pick<Partner,'id'|'name_ar'|'name_en'|'city'|'logo_url'|'website_url'|'status'|'show_home'|'sort_order'>
export async function listPublicPartners():Promise<Partner[]>{
 const {data,error}=await supabase.from('authorized_partners').select('*').eq('status','APPROVED').order('sort_order',{ascending:true}).order('name_ar',{ascending:true}).limit(1000)
 if(error)throw error
 return (data??[]) as Partner[]
}
export async function listManagedPartners():Promise<Partner[]>{
 const {data,error}=await supabase.rpc('dashboard_list_authorized_partners')
 if(error)throw error
 return (data??[]) as Partner[]
}
export async function savePartner(partner:PartnerInput):Promise<Partner>{
 const {data,error}=await supabase.rpc('dashboard_save_authorized_partner',{p_payload:partner})
 if(error)throw error
 return data as Partner
}
export async function removePartner(id:string):Promise<void>{
 const {error}=await supabase.rpc('dashboard_delete_authorized_partner',{p_partner_id:id})
 if(error)throw error
}
