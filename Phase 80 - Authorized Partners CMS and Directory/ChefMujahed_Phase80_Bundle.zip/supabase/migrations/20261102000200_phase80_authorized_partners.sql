CREATE TABLE IF NOT EXISTS public.authorized_partners(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name_ar text NOT NULL CHECK(length(btrim(name_ar)) BETWEEN 2 AND 160),
 name_en text,city text,logo_url text,website_url text,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','APPROVED','INACTIVE')),
 show_home boolean NOT NULL DEFAULT false,sort_order integer NOT NULL DEFAULT 0,
 verified_at timestamptz,created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS authorized_partners_public_idx ON public.authorized_partners(status,show_home,sort_order);
ALTER TABLE public.authorized_partners ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.authorized_partners FROM anon,authenticated;
GRANT SELECT ON TABLE public.authorized_partners TO anon,authenticated;
GRANT ALL ON TABLE public.authorized_partners TO service_role;
DROP POLICY IF EXISTS authorized_partners_public_select ON public.authorized_partners;
CREATE POLICY authorized_partners_public_select ON public.authorized_partners FOR SELECT TO anon,authenticated USING(status='APPROVED');
CREATE OR REPLACE FUNCTION public.dashboard_list_authorized_partners()
RETURNS SETOF public.authorized_partners LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','auth' AS $$
BEGIN
 PERFORM public.dashboard_assert_role(ARRAY['SUPER_ADMIN','ADMIN']);
 RETURN QUERY SELECT * FROM public.authorized_partners ORDER BY sort_order,name_ar;
END; $$;
CREATE OR REPLACE FUNCTION public.dashboard_save_authorized_partner(p_payload jsonb)
RETURNS public.authorized_partners LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','auth' AS $$
DECLARE v_id uuid; v_status text; v_name text; v_logo text; v_website text; v_result public.authorized_partners;
BEGIN
 PERFORM public.dashboard_assert_role(ARRAY['SUPER_ADMIN','ADMIN']);
 v_id:=COALESCE(NULLIF(p_payload->>'id','')::uuid,gen_random_uuid());
 v_name:=btrim(COALESCE(p_payload->>'name_ar',''));v_status:=COALESCE(p_payload->>'status','DRAFT');
 v_logo:=NULLIF(btrim(COALESCE(p_payload->>'logo_url','')),'');
 v_website:=NULLIF(btrim(COALESCE(p_payload->>'website_url','')),'');
 IF length(v_name) NOT BETWEEN 2 AND 160 THEN RAISE EXCEPTION 'اسم الشريك مطلوب'; END IF;
 IF v_status NOT IN ('DRAFT','APPROVED','INACTIVE') THEN RAISE EXCEPTION 'حالة الاعتماد غير صالحة'; END IF;
 IF v_status='APPROVED' AND (v_logo IS NULL OR v_logo !~* '^https://') THEN RAISE EXCEPTION 'شعار صالح مطلوب قبل اعتماد الشريك'; END IF;
 IF v_website IS NOT NULL AND v_website !~* '^https://[^[:space:]]+$' THEN RAISE EXCEPTION 'رابط الموقع يجب أن يبدأ بـ https://'; END IF;
 INSERT INTO public.authorized_partners(id,name_ar,name_en,city,logo_url,website_url,status,show_home,sort_order,verified_at)
 VALUES(v_id,v_name,NULLIF(btrim(COALESCE(p_payload->>'name_en','')),''),NULLIF(btrim(COALESCE(p_payload->>'city','')),''),
 v_logo,v_website,v_status,COALESCE((p_payload->>'show_home')::boolean,false),
 COALESCE((p_payload->>'sort_order')::integer,0),CASE WHEN v_status='APPROVED' THEN now() ELSE NULL END)
 ON CONFLICT(id) DO UPDATE SET
 name_ar=EXCLUDED.name_ar,name_en=EXCLUDED.name_en,city=EXCLUDED.city,logo_url=EXCLUDED.logo_url,
 website_url=EXCLUDED.website_url,status=EXCLUDED.status,show_home=EXCLUDED.show_home,
 sort_order=EXCLUDED.sort_order,updated_at=now(),
 verified_at=CASE WHEN EXCLUDED.status='APPROVED' THEN COALESCE(public.authorized_partners.verified_at,now()) ELSE NULL END
 RETURNING * INTO v_result;
 RETURN v_result;
END; $$;
CREATE OR REPLACE FUNCTION public.dashboard_delete_authorized_partner(p_partner_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','auth' AS $$
BEGIN
 PERFORM public.dashboard_assert_role(ARRAY['SUPER_ADMIN','ADMIN']);
 DELETE FROM public.authorized_partners WHERE id=p_partner_id;
 RETURN FOUND;
END; $$;
REVOKE ALL ON FUNCTION public.dashboard_list_authorized_partners() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.dashboard_save_authorized_partner(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.dashboard_delete_authorized_partner(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.dashboard_list_authorized_partners() TO authenticated;
GRANT EXECUTE ON FUNCTION public.dashboard_save_authorized_partner(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dashboard_delete_authorized_partner(uuid) TO authenticated;
