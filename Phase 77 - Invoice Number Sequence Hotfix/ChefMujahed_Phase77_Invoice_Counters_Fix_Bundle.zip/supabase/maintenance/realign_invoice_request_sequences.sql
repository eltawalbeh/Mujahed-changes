-- Chef Mujahed Phase 77 - Supabase BACKUP sequence realignment.
-- Production hotfix was applied on 2026-11-01; keep as an auditable,
-- idempotent maintenance bundle. Run ONLY against the intended backup project.
-- This preserves existing invoices and requests, and does not reissue numbers.
BEGIN;
LOCK TABLE public.requests IN SHARE MODE;
WITH bounds AS (
 SELECT
  COALESCE(MAX((substring(invoice_number from '([0-9]+)$'))::bigint), 999) AS invoice_max,
  COALESCE(MAX((substring(reference from '([0-9]+)$'))::bigint), 0) AS reference_max
 FROM public.requests
)
SELECT
 setval('public.invoice_number_seq'::regclass, GREATEST((SELECT last_value FROM public.invoice_number_seq), (SELECT invoice_max FROM bounds)), true) AS invoice_sequence_now,
 setval('public.request_reference_seq'::regclass, GREATEST((SELECT last_value FROM public.request_reference_seq), (SELECT reference_max FROM bounds)), true) AS reference_sequence_now;
COMMIT;
