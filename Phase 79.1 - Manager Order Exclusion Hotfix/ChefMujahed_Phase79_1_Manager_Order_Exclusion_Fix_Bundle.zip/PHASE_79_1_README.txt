Phase 79.1 — Admin Order Exclusion Hotfix

Root cause:
- Phase 79 enabled ADMIN and SUPER_ADMIN on UI and public.dashboard_remove_request.
- src/data/dashboard.ts still blocked every role except SUPER_ADMIN locally before making the RPC call.
- This was the exact source of the manager's error: "حذف الطلبات متاح لمدير النظام فقط."

Apply:
Replace src/data/dashboard.ts with the bundled file via Figma Make. Keep all other files unchanged. Push & Publish.

Post-apply verification:
1. Log in as ADMIN (manager), open an ordinary test order.
2. Select حذف الطلب; enter an audit reason (5-500 characters) and the exact order reference.
3. Confirm: the request should leave operational lists; financial records are retained, and reason is logged.
4. Verify SUPER_ADMIN can use the same flow.
5. Verify a SUPERVISOR cannot access the deletion action.

No SQL migration, no direct runtime edits, and no changes to existing orders are required by this hotfix.
