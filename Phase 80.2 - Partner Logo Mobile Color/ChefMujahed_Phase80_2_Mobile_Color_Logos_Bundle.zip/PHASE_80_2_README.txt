Chef Mujahed — Phase 80.2 — Partner Logos Mobile Color

Replace only src/components/public/AuthorizedPartnersSection.tsx using the bundled file.

Behavior:
- Mobile and tablet (<1024px): original colored logos all the time, no tap required.
- Desktop (>=1024px): monochrome by default, full color on hover, focus-within, or active.
- The same PartnerLogo component is used by homepage and public partners directory.
- No data, CMS, layout, responsive grid, logo links, or Supabase changes.

Apply through Figma Make, then Push & Publish. Test on mobile and desktop.
