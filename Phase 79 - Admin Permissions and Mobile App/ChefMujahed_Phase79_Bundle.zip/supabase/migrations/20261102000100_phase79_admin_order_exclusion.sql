CREATE OR REPLACE FUNCTION public.dashboard_remove_request(p_request_id uuid,p_reference_confirmation text,p_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','auth' AS $$
DECLARE v_req public.requests%rowtype; v_reason text:=btrim(coalesce(p_reason,''));
BEGIN
 PERFORM public.dashboard_assert_role(ARRAY['SUPER_ADMIN','ADMIN']);
 IF length(v_reason) NOT BETWEEN 5 AND 500 THEN RAISE EXCEPTION 'يجب كتابة سبب واضح للحذف (5 إلى 500 حرف)'; END IF;
 SELECT * INTO v_req FROM public.requests WHERE id=p_request_id FOR UPDATE;
 IF NOT FOUND OR v_req.deleted_at IS NOT NULL THEN RAISE EXCEPTION 'الطلب غير موجود أو سبق استبعاده'; END IF;
 IF btrim(coalesce(p_reference_confirmation,'')) IS DISTINCT FROM v_req.reference THEN RAISE EXCEPTION 'رقم تأكيد الطلب غير مطابق'; END IF;
 UPDATE public.requests SET deleted_at=now(),deleted_by=auth.uid(),deleted_reason=v_reason,updated_at=now() WHERE id=p_request_id AND deleted_at IS NULL;
 INSERT INTO public.request_activity(request_id,action_type,description,actor_id,metadata)
 VALUES(p_request_id,'ORDER_EXCLUDED_FROM_OPERATIONS','إزالة الطلب من التشغيل والتقارير: '||v_reason,auth.uid(),
 jsonb_build_object('reason',v_reason,'originalStatus',v_req.status,'paymentStatus',v_req.payment_status,'invoiceNumber',v_req.invoice_number,'preservedForFinancialAudit',true));
 RETURN jsonb_build_object('removed',true,'id',p_request_id,'reference',v_req.reference,'invoicePreserved',v_req.invoice_issued_at IS NOT NULL);
END; $$;