import { useCallback,useEffect,useState } from 'react'
import { ArrowClockwise,ChartLineUp } from '@phosphor-icons/react'
import { fetchGA4Report,type GA4Report } from '@/data/ga4Reports'
type Period=7|30|90
const format=(n:number)=>Number(n||0).toLocaleString('en-US')
export default function GoogleAnalyticsPanel(){
 const [days,setDays]=useState<Period>(30)
 const [data,setData]=useState<GA4Report|null>(null)
 const [loading,setLoading]=useState(true)
 const [error,setError]=useState('')
 const load=useCallback(async()=>{setLoading(true);setError('');try{setData(await fetchGA4Report(days))}catch(e){setData(null);setError(e instanceof Error?e.message:'تعذر تحميل البيانات')}finally{setLoading(false)}},[days])
 useEffect(()=>{void load()},[load])
 return <section aria-labelledby="ga4-heading" className="space-y-5 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4 lg:p-6">
  <div className="flex flex-wrap items-center justify-between gap-3">
   <div><h2 id="ga4-heading" className="flex items-center gap-2 text-xl font-bold"><ChartLineUp size={23}/>Google Analytics — التسويق والزيارات</h2>
   <p className="mt-2 text-xs text-[var(--color-text-muted)]">زيارات الموقع وتحويلاته في Google Analytics، مستقلة عن بيانات الطلبات المالية أدناه.</p></div>
   <button type="button" onClick={()=>void load()} disabled={loading} aria-label="تحديث بيانات Google Analytics" className="grid size-11 place-items-center rounded-xl border border-[var(--color-border)] disabled:opacity-50"><ArrowClockwise size={20}/></button>
  </div>
  <div role="group" aria-label="الفترة الزمنية لإحصاءات الزيارات" className="flex gap-2">{([7,30,90] as Period[]).map(x=><button key={x} type="button" onClick={()=>setDays(x)} aria-pressed={days===x} className={'min-h-10 rounded-xl px-4 text-sm '+(days===x?'bg-[var(--color-text)] text-white':'bg-[var(--color-bg)] text-[var(--color-text)]')}>آخر {x} أيام</button>)}</div>
  {loading?<p role="status" className="text-sm">جاري تحميل بيانات Google Analytics…</p>:null}
  {error?<p role="alert" className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">{error}</p>:null}
  {data&&!loading?<>
   <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
    {([['المستخدمون النشطون',data.activeUsers],['الجلسات',data.sessions],['مشاهدات الصفحات',data.pageViews],['إرسال الطلب',data.orderSubmittedEvents]] as const).map(([label,count])=><article key={label} className="rounded-xl border border-[var(--color-border)] bg-[var(--color-bg)] p-4"><p className="text-xs text-[var(--color-text-muted)]">{label}</p><strong dir="ltr" className="mt-3 block text-right text-2xl">{format(count)}</strong></article>)}
   </div>
   <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
    {([['Instagram',data.instagramSessions],['Facebook',data.facebookSessions],['Google',data.googleSessions],['Direct',data.directSessions]] as const).map(([label,count])=><article key={label} className="rounded-xl border border-[var(--color-border)] p-4"><p className="text-xs text-[var(--color-text-muted)]">{label}</p><strong dir="ltr" className="mt-2 block text-right text-xl">{format(count)}</strong><p className="mt-1 text-xs text-[var(--color-text-muted)]">جلسة منسوبة للمصدر</p></article>)}
   </div>
   <h3 className="font-bold">أبرز مصادر الزيارات (Source / Medium)</h3>
   <div className="space-y-3">{data.sources.length?data.sources.map(item=><div key={item.name}><div className="flex items-center justify-between gap-3 text-xs"><strong>{format(item.sessions)}</strong><span dir="ltr" className="truncate">{item.name}</span></div><div className="mt-1.5 h-2 overflow-hidden rounded-full bg-[var(--color-bg)]"><div className="h-full rounded-full bg-[var(--color-accent)]" style={{width:(100*item.sessions/Math.max(1,data.sources[0]?.sessions||1))+'%'}}/></div></div>):<p className="text-sm text-[var(--color-text-muted)]">لا توجد بيانات لهذه الفترة.</p>}</div>
   <p className="text-xs leading-6 text-[var(--color-text-muted)]">الفترة تنتهي في {data.throughDate} · آخر جلب {new Date(data.updatedAt).toLocaleString('ar-JO')} · إرسال الطلب = حدث order_submitted وليس عملية بيع مؤكدة. قد تظهر بعض زيارات Instagram كزيارات مباشرة إذا لم يُحفظ مصدرها.</p>
  </>:null}
 </section>
}
