import { supabase } from '@/lib/supabase'
export type GA4Source={name:string;sessions:number;users:number}
export type GA4Report={periodDays:number;throughDate:string;updatedAt:string;activeUsers:number;sessions:number;pageViews:number;orderSubmittedEvents:number;instagramSessions:number;facebookSessions:number;googleSessions:number;directSessions:number;sources:GA4Source[]}
export async function fetchGA4Report(days:7|30|90):Promise<GA4Report>{
 const {data,error}=await supabase.functions.invoke('ga4-dashboard',{body:{days}})
 if(error){
  const context=error.context as Response|undefined
  if(context?.status===503)throw new Error('ربط Google Analytics غير مهيأ بعد؛ يلزم إعداد GA4 في Supabase.')
  if(context?.status===403)throw new Error('تقارير Google Analytics متاحة للمدير ومدير النظام فقط.')
  throw new Error('تعذر قراءة Google Analytics. تأكد من نشر Edge Function وصلاحية الاتصال.')
 }
 if(!data||typeof data.sessions!=='number')throw new Error('استجابة Google Analytics غير صالحة')
 return data as GA4Report
}
