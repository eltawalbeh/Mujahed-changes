import { createClient } from 'jsr:@supabase/supabase-js@2'
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'}
const json=(payload:unknown,status=200)=>new Response(JSON.stringify(payload),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'private,no-store'}})
const cache=new Map<string,{expires:number;data:unknown}>()
const encoder=new TextEncoder()
const b64url=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
async function tokenFromServiceAccount(email:string,pem:string){
 const der=Uint8Array.from(atob(pem.replace(/-----[^-]+-----|\s/g,'')),c=>c.charCodeAt(0))
 const key=await crypto.subtle.importKey('pkcs8',der,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign'])
 const seconds=Math.floor(Date.now()/1000)
 const head=b64url(encoder.encode(JSON.stringify({alg:'RS256',typ:'JWT'})))
 const body=b64url(encoder.encode(JSON.stringify({iss:email,scope:'https://www.googleapis.com/auth/analytics.readonly',aud:'https://oauth2.googleapis.com/token',iat:seconds,exp:seconds+3500})))
 const unsigned=head+'.'+body
 const sign=b64url(new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,encoder.encode(unsigned))))
 const form=new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:unsigned+'.'+sign})
 const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form})
 if(!response.ok)throw Error('GA4_OAUTH_FAILED')
 const payload=await response.json()
 if(!payload.access_token)throw Error('GA4_OAUTH_FAILED')
 return String(payload.access_token)
}
type Row={dimensionValues?:Array<{value:string}>;metricValues?:Array<{value:string}>}
type Report={rows?:Row[];totals?:Row[]}
Deno.serve(async(request)=>{
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors})
 if(request.method!=='POST')return json({code:'METHOD_NOT_ALLOWED'},405)
 const url=Deno.env.get('SUPABASE_URL')||''
 const secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||''
 if(!url||!secret)return json({code:'SERVER_CONFIG_ERROR'},503)
 const header=request.headers.get('Authorization')||''
 const jwt=header.replace(/^Bearer\s+/i,'')
 if(!header||jwt===header)return json({code:'UNAUTHORIZED'},401)
 const client=createClient(url,secret)
 const {data:{user},error:authError}=await client.auth.getUser(jwt)
 if(authError||!user)return json({code:'UNAUTHORIZED'},401)
 const {data:staff,error:accessError}=await client.from('dashboard_users').select('role,status').eq('user_id',user.id).maybeSingle()
 if(accessError||!staff||staff.status!=='ACTIVE'||!['SUPER_ADMIN','ADMIN'].includes(staff.role))return json({code:'FORBIDDEN'},403)
 const property=Deno.env.get('GA4_PROPERTY_ID')||''
 let credentials:{client_email?:string;private_key?:string}
 try{credentials=JSON.parse(Deno.env.get('GA4_SERVICE_ACCOUNT_JSON')||'{}')}catch{return json({code:'GA4_NOT_CONFIGURED'},503)}
 if(!/^\d+$/.test(property)||!credentials.client_email||!credentials.private_key)return json({code:'GA4_NOT_CONFIGURED'},503)
 let input:{days?:number}
 try{input=await request.json()}catch{return json({code:'INVALID_INPUT'},400)}
 const days=Number(input.days??30)
 if(![7,30,90].includes(days))return json({code:'INVALID_PERIOD'},400)
 const key=property+':'+days
 const previous=cache.get(key)
 if(previous&&previous.expires>Date.now())return json(previous.data)
 try{
  const access=await tokenFromServiceAccount(credentials.client_email,credentials.private_key)
  const run=async(options:Record<string,unknown>):Promise<Report>=>{
   const response=await fetch('https://analyticsdata.googleapis.com/v1beta/properties/'+property+':runReport',{
    method:'POST',headers:{Authorization:'Bearer '+access,'Content-Type':'application/json'},
    body:JSON.stringify({...options,dateRanges:[{startDate:days+'daysAgo',endDate:'yesterday'}]})
   })
   if(!response.ok){console.error('GA4 report response',response.status);throw Error('GA4_REPORT_FAILED')}
   return await response.json()
  }
  const [summary,channels,event]=await Promise.all([
   run({metrics:[{name:'activeUsers'},{name:'sessions'},{name:'screenPageViews'}],metricAggregations:['TOTAL']}),
   run({dimensions:[{name:'sessionSourceMedium'}],metrics:[{name:'sessions'},{name:'activeUsers'}],orderBys:[{metric:{metricName:'sessions'},desc:true}],limit:'100'}),
   run({dimensions:[{name:'eventName'}],metrics:[{name:'eventCount'}],dimensionFilter:{filter:{fieldName:'eventName',stringFilter:{matchType:'EXACT',value:'order_submitted'}}},limit:'10'})
  ])
  const n=(value?:string)=>{const result=Number(value||0);return Number.isFinite(result)?result:0}
  const m=summary.totals?.[0]?.metricValues||summary.rows?.[0]?.metricValues||[]
  const sources=(channels.rows||[]).map(x=>({name:x.dimensionValues?.[0]?.value||'(not set)',sessions:n(x.metricValues?.[0]?.value),users:n(x.metricValues?.[1]?.value)}))
  const traffic=(pattern:RegExp)=>sources.filter(x=>pattern.test(x.name)).reduce((total,x)=>total+x.sessions,0)
  const value={periodDays:days,updatedAt:new Date().toISOString(),throughDate:new Date(Date.now()-86400000).toISOString().slice(0,10),
   activeUsers:n(m[0]?.value),sessions:n(m[1]?.value),pageViews:n(m[2]?.value),
   orderSubmittedEvents:(event.rows||[]).reduce((total,x)=>total+n(x.metricValues?.[0]?.value),0),
   instagramSessions:traffic(/instagram/i),facebookSessions:traffic(/facebook|fb\.com/i),googleSessions:traffic(/(^|[\/ ])google([\/ ]|$)/i),directSessions:traffic(/^\(direct\)/i),
   sources:sources.slice(0,10)}
  cache.set(key,{expires:Date.now()+300000,data:value})
  return json(value)
 }catch(error){console.error('GA4 fetch failed',error instanceof Error?error.message:'unknown');return json({code:'GA4_FETCH_FAILED'},502)}
})
